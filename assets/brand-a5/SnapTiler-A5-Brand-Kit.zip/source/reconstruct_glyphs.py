#!/usr/bin/env python3
"""Read the selected concept's silhouette as geometry, then build editable SVG paths.

The input PNG is read-only. No raster image is modified or produced here.
Chinese curves retain the selected A character; structural parts and Latin are redrawn.
"""
from pathlib import Path
import json
import numpy as np
from PIL import Image
from fontTools.svgLib.path import parse_path
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parents[2]
REFERENCE = ROOT / 'source/reference-A-selected.png'

def rdp(points, epsilon):
    if len(points) < 3: return points
    a, b = points[0], points[-1]
    v = b-a
    if np.linalg.norm(v) == 0: distances = np.linalg.norm(points-a, axis=1)
    else: distances = np.abs(v[0]*(points[:,1]-a[1])-v[1]*(points[:,0]-a[0]))/np.linalg.norm(v)
    i = int(np.argmax(distances))
    if distances[i] <= epsilon: return np.array([a,b])
    return np.vstack((rdp(points[:i+1],epsilon)[:-1],rdp(points[i:],epsilon)))

def contours(mask):
    h,w=mask.shape; edges={}
    for y,x in zip(*np.where(mask)):
        if y==0 or not mask[y-1,x]: edges[(x,y)]=(x+1,y)
        if x==w-1 or not mask[y,x+1]: edges[(x+1,y)]=(x+1,y+1)
        if y==h-1 or not mask[y+1,x]: edges[(x+1,y+1)]=(x,y+1)
        if x==0 or not mask[y,x-1]: edges[(x,y+1)]=(x,y)
    result=[]
    while edges:
        start=next(iter(edges)); p=start; pts=[]
        while p in edges:
            pts.append(p);p=edges.pop(p)
            if p==start:break
        if len(pts)>30:result.append(np.array(pts,dtype=float))
    return result

def unit(v):return v/(np.linalg.norm(v) or 1)

def fit_cubics(points, t1, t2, error=1.25):
    # Least-squares cubic fitting with recursive maximum-error splitting.
    # Control points are calculated from the contour geometry, not pixel stair-steps.
    if len(points)==2:
        d=np.linalg.norm(points[1]-points[0])/3
        return [np.array([points[0],points[0]+t1*d,points[1]+t2*d,points[1]])]
    lengths=np.linalg.norm(np.diff(points,axis=0),axis=1)
    u=np.r_[0,np.cumsum(lengths)];u/=u[-1] or 1
    b0=(1-u)**3;b1=3*u*(1-u)**2;b2=3*u*u*(1-u);b3=u**3
    a0=b1[:,None]*t1;a1=b2[:,None]*t2
    residual=points-(b0+b1)[:,None]*points[0]-(b2+b3)[:,None]*points[-1]
    mat=np.array([[np.sum(a0*a0),np.sum(a0*a1)],[np.sum(a0*a1),np.sum(a1*a1)]])
    rhs=np.array([np.sum(a0*residual),np.sum(a1*residual)])
    try:alpha=np.linalg.solve(mat,rhs)
    except np.linalg.LinAlgError:alpha=np.zeros(2)
    chord=np.linalg.norm(points[-1]-points[0])
    if min(alpha)<1e-5 or max(alpha)>max(1,chord)*3:alpha[:]=chord/3
    curve=np.array([points[0],points[0]+alpha[0]*t1,points[-1]+alpha[1]*t2,points[-1]])
    fitted=b0[:,None]*curve[0]+b1[:,None]*curve[1]+b2[:,None]*curve[2]+b3[:,None]*curve[3]
    distances=np.sum((fitted-points)**2,axis=1);split=int(np.argmax(distances))
    if distances[split]<=error**2:return [curve]
    split=min(max(split,1),len(points)-2)
    tangent=unit(points[split-1]-points[split+1])
    return fit_cubics(points[:split+1],t1,tangent,error)+fit_cubics(points[split:],-tangent,t2,error)

def vector_curve(points, sx, sy, ox=0, oy=0):
    # Smooth contour samples before curve fitting to discard subpixel raster noise.
    weights=np.array([1,2,3,4,5,4,3,2,1],dtype=float);weights/=weights.sum()
    clean=sum(np.roll(points,i-4,axis=0)*weight for i,weight in enumerate(weights))
    clean=clean[::2];clean=np.vstack((clean,clean[:1]))
    curves=fit_cubics(clean,unit(clean[3]-clean[0]),unit(clean[-4]-clean[-1]))
    curves=[curve*np.array([sx,sy])+np.array([ox,oy]) for curve in curves]
    start=curves[0][0];parts=[f'M{start[0]:.3f} {start[1]:.3f}']
    for curve in curves:
        a,b,c,d=curve
        # Snap near-horizontal/vertical controls in long, visually straight runs.
        if np.ptp(curve[:,1])<.3 and abs(a[0]-d[0])>6:
            parts.append(f'L{d[0]:.3f} {a[1]:.3f}')
        elif np.ptp(curve[:,0])<.3 and abs(a[1]-d[1])>6:
            parts.append(f'L{a[0]:.3f} {d[1]:.3f}')
        else:parts.append('C'+' '.join(f'{v:.3f}' for v in curve[1:].flatten()))
    return ' '.join(parts)+' Z'

def rr(x,y,w,h,r):
    return f'M{x+r} {y} H{x+w-r} Q{x+w} {y} {x+w} {y+r} V{y+h-r} Q{x+w} {y+h} {x+w-r} {y+h} H{x+r} Q{x} {y+h} {x} {y+h-r} V{y+r} Q{x} {y} {x+r} {y} Z'

def normalize_path(d,width,height):
    bounds=BoundsPen(None);parse_path(d,bounds)
    x0,y0,x1,y1=bounds.bounds;sx=width/(x1-x0);sy=height/(y1-y0)
    out=SVGPathPen(None);parse_path(d,TransformPen(out,(sx,0,0,sy,-x0*sx,-y0*sy)))
    return out.getCommands()

def main():
    rgb=np.asarray(Image.open(REFERENCE).convert('RGB'))
    chuang=contours(np.max(rgb[234:582,236:593],axis=2)<150)
    duo=contours(np.max(rgb[237:582,621:958],axis=2)<150)
    # Wordmark outline file is independent of fonts and of the reference image at render time.
    # Keep the 30-unit main bar introduced in A4; A5 restores A0's two square dots.
    roof='M85 0 H112 Q122 0 122 10 V16 H183 Q200 16 200 33 V54 Q200 60 194 60 H168 V50 Q168 46 164 46 H36 Q32 46 32 50 V60 H6 Q0 60 0 54 V33 Q0 16 17 16 H76 V9 Q76 0 85 0 Z'
    left=vector_curve(chuang[1],200/357,200/348)
    enclosure='M29 97 H79 L88 82 Q90 79 94 79 H115 Q120 79 118 84 L112 97 H174 Q190 97 190 113 V184 Q190 200 174 200 H29 Q13 200 13 184 V113 Q13 97 29 97 Z '
    enclosure+=rr(44,124,115,51,4)
    # A0 reference: two equal, level, rounded-square dots, integrated as heavy glyph parts.
    # 33-unit dot width matches the 31-unit frame sides; white gaps stay open at small sizes.
    face_parts=[{'d':rr(61,133,33,33,6)}, {'d':rr(109,133,33,33,6)}]
    glyphs={
      'chuang':{'width':200,'height':200,'parts':[{'d':roof},{'d':left,'stroke':'currentColor','stroke-width':'4','stroke-linejoin':'round','transform':'matrix(1 0 0 .82 .5 13)'},{'d':left,'stroke':'currentColor','stroke-width':'4','stroke-linejoin':'round','transform':'matrix(-1 0 0 .82 199.5 13)'},{'d':enclosure,'fillRule':'evenodd'}]+face_parts},
      'duo':{'width':337*200/345,'height':200,'parts':[{'d':normalize_path(vector_curve(duo[0],200/345,200/345),337*200/345,200)}]},
    }
    en={
      'S':(110,[{'d':'M106 0 Q110 0 110 4 V18 Q110 23 105 23 H36 Q28 23 28 30 Q28 37 37 37 H77 C98 37 110 48 110 68 C110 87 96 100 73 100 H4 Q0 100 0 96 V81 Q0 77 4 77 H73 Q83 77 83 69 Q83 61 72 61 H35 C13 61 0 50 0 32 C0 12 15 0 38 0 Z'}]),
      'n':(84,[{'d':'M0 100 V60 C0 38 13 26 35 26 H49 C71 26 84 38 84 60 V96 Q84 100 80 100 H62 Q58 100 58 96 V61 Q58 50 47 50 H37 Q26 50 26 61 V96 Q26 100 22 100 H4 Q0 100 0 96 Z'}]),
      'a':(86,[{'d':'M8 26 H54 C75 26 86 38 86 57 V84 Q86 100 71 100 H28 Q0 100 0 77 Q0 55 28 55 H59 V53 Q59 48 51 48 H8 Q4 48 4 43 V31 Q4 26 8 26 Z '+rr(25,71,35,13,5),'fillRule':'evenodd'}]),
      'p':(91,[{'d':'M4 26 H54 C79 26 91 40 91 63 C91 86 78 100 55 100 H26 V125 Q26 129 22 129 H4 Q0 129 0 125 V30 Q0 26 4 26 Z '+rr(26,49,38,28,6),'fillRule':'evenodd'}]),
      'T':(87,[{'d':'M4 0 H83 Q87 0 87 4 V21 Q87 25 83 25 H57 V96 Q57 100 53 100 H34 Q30 100 30 96 V25 H4 Q0 25 0 21 V4 Q0 0 4 0 Z'}]),
      'i':(26,[{'d':rr(0,0,26,22,3),'transform':'matrix(1 -0.2679491924 0 1 0 6.9666790024)'},{'d':'M3 38.196 L22 33.105 Q26 32.033 26 36.174 V96 Q26 100 22 100 H4 Q0 100 0 96 V42.196 Q0 39 3 38.196 Z'}]),
      'l':(26,[{'d':rr(0,0,26,100,4)}]),
      'e':(90,[{'d':'M90 66 Q90 70 86 70 H28 Q31 80 45 80 H85 Q90 80 90 85 V95 Q90 100 85 100 H40 C14 100 0 86 0 63 C0 40 14 26 40 26 H53 C78 26 90 39 90 62 Z '+rr(28,46,35,11,4.5),'fillRule':'evenodd'}]),
      'r':(57,[{'d':'M0 96 V62 C0 38 15 26 41 26 H53 Q57 26 57 30 V46 Q57 50 53 50 H42 Q26 50 26 63 V96 Q26 100 22 100 H4 Q0 100 0 96 Z'}]),
    }
    for c,(w,parts) in en.items():glyphs[c]={'width':w,'height':129 if c=='p' else 100,'parts':parts}
    payload={'version':'A5.0','source':'selected A; A0 two-dot expression restored in the heavier A4 frame with current 穴 structure; 多 and Latin remain the A3 paths','glyphs':glyphs,'metrics':{'chinese_height':200,'chinese_tracking':20,'chuang_roof_weight':30,'chuang_frame_top_weight':27,'chuang_frame_bottom_weight':25,'chuang_frame_side_weights':[31,31],'chuang_dots':{'width':33,'height':33,'radius':6,'gap':15,'x':[61,109],'y':133},'latin_cap_height':100,'latin_x_height':74,'latin_baseline':100,'latin_descender':29,'latin_gaps':[9,9,9,10,12,12,12,10],'detail_angle_degrees':15}}
    (ROOT/'source/glyphs.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    print('Created 11 unique vector glyphs; 多 is reused, not redrawn twice.')

if __name__=='__main__':main()
