#!/usr/bin/env python3
"""Build a self-contained wordmark family from one editable vector source.

Only writes inside this refinement directory. Does not invoke older brand generators.
"""
from pathlib import Path
import json, html, re

ROOT=Path(__file__).resolve().parents[1]
PROJECT=ROOT.parents[2]
DATA=json.loads((ROOT/'source/glyphs.json').read_text())
GLYPHS=DATA['glyphs'];M=DATA['metrics']
GEOMETRY=json.loads((ROOT/'source/logo-geometry.json').read_text())
INK='#18213B';BLUE='#0876FA';IVORY='#FFFDF7'

def path_d(commands):return ' '.join(c[0]+' '.join(map(str,c[1:])) for c in commands)
def attrs(part):
    return ' '.join(f'{"fill-rule" if k=="fillRule" else k}="{v}"' for k,v in part.items())
def glyph_defs():
    return ''.join(f'<g id="glyph-{key}">'+''.join(f'<path {attrs(p)}/>' for p in g['parts'])+'</g>' for key,g in GLYPHS.items())
def wordmark(lang):
    x=0;parts=[]
    names=['chuang','duo','duo'] if lang=='zh' else list('SnapTiler')
    gaps=[20,20] if lang=='zh' else M['latin_gaps']
    for i,key in enumerate(names):
        parts.append(f'<use href="#glyph-{key}" transform="translate({x:.3f} 0)"/>')
        x+=GLYPHS[key]['width']+(gaps[i] if i<len(gaps) else 0)
    return ''.join(parts),x,200 if lang=='zh' else 129
WORDS={lang:wordmark(lang) for lang in ['zh','en']}

def symbol(variant='color',tile=False):
    ivory=path_d(GEOMETRY['ivory']);blue=path_d(GEOMETRY['blue']);smile=path_d(GEOMETRY['smile'])
    face='<rect x="226" y="418" width="47" height="109" rx="23.5"/><rect x="394" y="371" width="47" height="110" rx="23.5"/>'
    face+=f'<path d="{smile}" fill="none" stroke="currentColor" stroke-width="27" stroke-linecap="round"/>'
    if variant in ['color','dark']:
        # Quiet outline restores the white window silhouette when the lavender tile is absent.
        border='#8796AE' if variant=='color' else '#FFFDF7'
        # Only the exterior against the page gets a keyline; the interlock stays clean.
        edge='M401 738 L193 792 C153 802 120 774 120 733 L120 330 C120 292 141 268 177 258 L468 181 C511 170 548 202 548 246 L548 361'
        body=f'<path d="{blue}" fill="{BLUE}"/><path d="{ivory}" fill="{IVORY}"/><path d="{edge}" fill="none" stroke="{border}" stroke-width="10" stroke-linejoin="round"/><g fill="{INK}" color="{INK}">{face}</g>'
    else:
        c='#111111' if variant=='black' else '#FFFFFF'
        body=f'<path d="{ivory}" fill="none" stroke="{c}" stroke-width="27" stroke-linejoin="round"/><path d="{blue}" fill="{c}"/><g fill="{c}" color="{c}">{face}</g>'
    if tile:
        # Reference icon's existing artwork is included verbatim, not regenerated.
        svg=(ROOT/'source/app-symbol.svg').read_text()
        inner=svg[svg.index('>')+1:svg.rindex('</svg>')]
        return inner,1024,1024
    return f'<g transform="translate(-107 -163)">{body}</g>',800,740

def document(body,w,h,title):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w:.3f}" height="{h:.3f}" viewBox="0 0 {w:.3f} {h:.3f}" role="img" aria-label="{html.escape(title)}"><title>{html.escape(title)}</title><defs>{glyph_defs()}</defs>{body}</svg>\n'
def save(name,body,w,h,title):
    (ROOT/'svg'/f'{name}.svg').write_text(document(body,w,h,title))
def word_at(lang,x,y,scale,color=INK):
    return f'<g transform="translate({x} {y}) scale({scale})" fill="{color}" color="{color}">{WORDS[lang][0]}</g>'
def lockup(lang,variant='color',tile=False):
    D=160;icon,iw,ih=symbol(variant,tile);iscl=D/ih;iconw=iw*iscl
    gap=40;x=iconw+gap;c='#FFFFFF' if variant=='white' else '#111111' if variant=='black' else INK
    body=f'<g transform="scale({iscl})">{icon}</g>'
    if lang=='bilingual':
        zscale=.38;escale=.30;zh=200*zscale;eh=129*escale;linegap=12
        y=(D-zh-eh-linegap)/2
        body+=word_at('zh',x,y,zscale,c)+word_at('en',x+1,y+zh+linegap,escale,c)
        width=x+max(WORDS['zh'][1]*zscale,WORDS['en'][1]*escale+1)
    else:
        scale=.42 if lang=='zh' else .66
        body+=word_at(lang,x,(D-WORDS[lang][2]*scale)/2,scale,c)
        width=x+WORDS[lang][1]*scale
    return body,width,D

def text(x,y,s,size=20,color=INK,weight=400):
    return f'<text x="{x}" y="{y}" font-family="PingFang SC,Heiti SC,sans-serif" font-size="{size}" font-weight="{weight}" fill="{color}">{html.escape(s)}</text>'
def rule(x1,y,x2):return f'<path d="M{x1} {y} H{x2}" fill="none" stroke="#DCE0E7" stroke-width="1"/>'
def place_lockup(lang,x,y,width,variant='color',tile=False):
    b,w,h=lockup(lang,variant,tile)
    if tile:
        # Multiple identical app symbols on one proof board need scoped gradient IDs.
        prefix=f'app-{x}-{y}-'
        for name in re.findall(r'id="([^"]+)"',b):
            b=b.replace(f'id="{name}"',f'id="{prefix+name}"').replace(f'url(#{name})',f'url(#{prefix+name})')
    return f'<g transform="translate({x} {y}) scale({width/w})">{b}</g>'

def main():
    asset_metrics={}
    for v in ['color','dark','black','white']:
        b,w,h=symbol(v);save('symbol-free-'+v,b,w,h,'窗多多 / SnapTiler 无底板图形')
    for v,c in [('ink',INK),('black','#111111'),('white','#FFFFFF')]:
        for lang in ['zh','en']:
            b,w,h=WORDS[lang];save(f'wordmark-{lang}-{v}',f'<g fill="{c}" color="{c}">{b}</g>',w,h,'窗多多' if lang=='zh' else 'SnapTiler')
    for lang in ['bilingual','zh','en']:
        for v in ['color','black','white']:
            b,w,h=lockup(lang,v);name=f'lockup-{lang}-{v}';save(name,b,w,h,'窗多多 / SnapTiler '+lang)
            asset_metrics[name]={'width':w,'height':h}
        b,w,h=lockup(lang,'color',True);save(f'lockup-{lang}-app-color',b,w,h,'窗多多 / SnapTiler 紫底图标组合 '+lang)

    # Board 1: the three requested lockups.
    b='<rect width="1600" height="1300" fill="#FFFFFF"/>'
    b+=text(80,66,'SNAPTILER   /   IDENTITY REFINEMENT 05',18,'#7D8799',500)
    b+=text(80,126,'同一套字形，三种清晰的组合。',35,INK,600)
    b+=text(80,207,'01  无紫色底板 · 中英双语',19,'#768297')
    b+=place_lockup('bilingual',285,257,1030)
    b+=rule(80,687,1520)
    b+=text(80,747,'02  图形 + 中文',19,'#768297')
    b+=text(850,747,'03  图形 + 英文',19,'#768297')
    b+=place_lockup('zh',91,828,610)
    b+=place_lockup('en',852,846,655)
    b+=rule(80,1136,1520)
    b+=text(80,1190,'方案 A · 柔角几何',22,INK,600)
    b+=text(80,1232,'“窗”字加重  /  双点字形  /  共用字形路径  /  透明背景资产',18,'#768297')
    save('01-组合总览',b,1600,1300,'窗多多 / SnapTiler A5 三种组合')

    # Board 2: construction and exact source reuse, with primary lettering rendered large.
    b='<rect width="1600" height="1320" fill="#F8F9FC"/>'
    b+=text(80,65,'A5   /   LETTERING & GEOMETRY',18,'#7D8799',500)
    b+=text(80,126,'把细节，收进一套规则。',36,INK,600)
    b+=word_at('zh',188,200,1.9)+word_at('en',230,637,1.5)
    b+=rule(80,898,1520)
    b+=text(80,956,'01  字重与表情',21,INK,600)+text(80,996,'“窗”保留加厚笔画，框内回到双圆角方点。',18,'#768297')
    b+=text(590,956,'02  共享字形',21,INK,600)+text(590,996,'两个“多”引用同一份路径。',18,'#768297')
    b+=text(1100,956,'03  15° 字点',21,INK,600)+text(1100,996,'i 的字点与窗口上扬方向一致。',18,'#768297')
    b+=f'<g transform="translate(100 1002) scale(.88)" fill="{INK}" color="{INK}"><use href="#glyph-chuang"/></g>'
    b+=f'<g transform="translate(616 1046) scale(.6)" fill="{INK}"><use href="#glyph-duo"/><use href="#glyph-duo" transform="translate(220 0)"/></g>'
    b+=f'<g transform="translate(1154 1065) scale(3.3)" fill="{INK}"><path d="M3 0 H23 Q26 0 26 3 V19 Q26 22 23 22 H3 Q0 22 0 19 V3 Q0 0 3 0Z" transform="matrix(1 -0.2679491924 0 1 0 6.9666790024)"/></g>'
    b+=text(1288,1124,'15°',31,INK,600)
    b+=text(80,1255,'字标全部为路径；双点与粗笔画统一，独立 logo 保持原有表情。',18,'#768297')
    save('02-字形与规范',b,1600,1320,'A5 字形与共用规则')

    # Board 3: real-size and background proof, plus app-icon variants.
    b='<rect width="1600" height="1380" fill="#FFFFFF"/>'
    b+=text(80,65,'A5   /   BACKGROUNDS & SCALE',18,'#7D8799',500)
    b+=text(80,126,'去底板之后，也要站得住。',36,INK,600)
    b+='<rect x="80" y="190" width="690" height="325" rx="20" fill="#F1F3F8"/>'
    b+=place_lockup('bilingual',148,250,550)
    b+=text(110,478,'浅底 · 白窗细边线',17,'#768297')
    b+=f'<rect x="830" y="190" width="690" height="325" rx="20" fill="{INK}"/>'
    b+=place_lockup('bilingual',898,250,550,'white')
    b+=text(860,478,'深底 · 单色反白',17,'#BAC3D5')
    b+=text(80,589,'真实尺寸校样（以 1600 px 原图 100% 查看）',21,INK,600)
    b+=place_lockup('bilingual',80,650,240)
    b+=place_lockup('zh',610,650,180)
    b+=place_lockup('en',1140,650,240)
    b+=text(80,781,'双语 240 px',17,'#768297')+text(610,781,'中文 180 px',17,'#768297')+text(1140,781,'英文 240 px',17,'#768297')
    b+=rule(80,840,1520)
    b+=text(80,913,'保留紫底图标的配套组合',21,INK,600)
    b+=place_lockup('zh',80,977,535,'color',True)
    b+=place_lockup('en',844,1000,655,'color',True)
    b+=text(80,1280,'无底板版本用于品牌组合；紫底图标版本用于需要明确 App 图标识别的场景。',18,'#768297')
    save('03-背景与尺寸校样',b,1600,1380,'A5 深浅背景与尺寸校样')
    # Exact same size and ink for a fair comparison of the requested revision.
    previous=json.loads((ROOT/'source/revisions/A4-glyphs.json').read_text())['glyphs']['chuang']
    old='<defs><g id="old-chuang">'+''.join(f'<path {attrs(p)}/>' for p in previous['parts'])+'</g></defs>'
    b='<rect width="1600" height="650" fill="#FFFFFF"/>'+old
    b+=text(80,66,'A5   /   WEIGHT & EXPRESSION',18,'#7D8799',500)
    b+=text(80,130,'回到双点，让表情融进字形。',35,INK,600)
    b+=text(80,218,'上一轮 · 完整笑脸',21,'#768297')+text(850,218,'本轮 · 双圆角方点',21,INK,600)
    b+=f'<g transform="translate(80 274)" fill="{INK}" color="{INK}">{WORDS["zh"][0].replace("#glyph-chuang","#old-chuang")}</g>'
    b+=word_at('zh',850,274,1)
    b+=rule(80,520,1520)
    b+=text(80,570,'细长眼睛与嘴部曲线，和厚实的字形脱节。',19,'#768297')
    b+=text(850,570,'回到 A0 的双点处理，保留加厚笔画与穴字头。',19,'#768297')
    b+=text(80,617,'同样字高、同样颜色、同样字距进行比较。',15,'#8993A5')
    save('04-窗字修改前后',b,1600,650,'窗字完整笑脸与双点修订对比')
    (ROOT/'source/metrics.json').write_text(json.dumps({'glyph_metrics':M,'wordmarks':{k:{'width':v[1],'height':v[2]} for k,v in WORDS.items()},'lockups':asset_metrics,'clear_space_ratio_of_symbol_height':.25,'suggested_minimum_width_px':{'bilingual':240,'zh':180,'en':240,'symbol':32}},indent=2)+'\n')
    print(f'Built {len(list((ROOT/"svg").glob("*.svg")))} SVG files in refinement directory only.')

if __name__=='__main__':main()
