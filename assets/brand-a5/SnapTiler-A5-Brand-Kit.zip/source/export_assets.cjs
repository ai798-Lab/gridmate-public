const fs=require('fs');
const path=require('path');
const sharp=require(process.env.SHARP_MODULE || 'sharp');
const root=path.resolve(__dirname,'..');
(async()=>{
  for(const name of fs.readdirSync(path.join(root,'svg')).filter(n=>n.endsWith('.svg'))){
    const board=/^0[1234]-/.test(name);
    const input=path.join(root,'svg',name);
    await sharp(input,{density:board?72:144}).png().toFile(path.join(root,'png',name.replace('.svg','.png')));
  }
  console.log('Rendered every native SVG to PNG; transparent artwork preserved.');
})().catch(e=>{console.error(e);process.exit(1)});
