#!/usr/bin/env python3
from pathlib import Path
import json, html, shutil
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor, Color
from reportlab.lib.utils import ImageReader
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
pdfmetrics.registerFont(TTFont('CN','/System/Library/Fonts/Supplemental/Arial Unicode.ttf'))
W,H=960,640;INK='#18213B';BLUE='#0876FA';MUTED='#69788E';PAPER='#F6F8FB'
out=ROOT/'窗多多-SnapTiler-VI规范使用手册.pdf'
c=canvas.Canvas(str(out),pagesize=(W,H));c.setTitle('窗多多 / SnapTiler · VI 规范使用手册 1.0');c.setAuthor('ai798Lab')
pages=[];current=[];page_no=0

def text(x,y,s,size=13,color=INK):
    c.setFillColor(HexColor(color));c.setFont('CN',size);c.drawString(x,H-y-size,s)
def para(x,y,s,width=380,size=13,color=MUTED,leading=23):
    line='';yy=y
    for char in s:
        if char=='\n' or pdfmetrics.stringWidth(line+char,'CN',size)>width:
            text(x,yy,line,size,color);line='';yy+=leading
            if char=='\n':continue
        line+=char
    if line:text(x,yy,line,size,color)
    return yy+leading
def rect(x,y,w,h,fill,stroke=None):
    c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(stroke or fill));c.rect(x,H-y-h,w,h,fill=1,stroke=bool(stroke))
def line(x1,y1,x2,y2,color='#DCE3EC',dash=None):
    c.setStrokeColor(HexColor(color));c.setLineWidth(.75);c.setDash(dash or []);c.line(x1,H-y1,x2,H-y2);c.setDash([])
def asset(name,x,y,w=None,h=None):
    path=ROOT/'PNG'/f'{name}.png'
    iw,ih=Image.open(path).size
    if w is None:w=h*iw/ih
    if h is None:h=w*ih/iw
    c.drawImage(ImageReader(str(path)),x,H-y-h,width=w,height=h,mask='auto')
    return w,h
def screenshot(name,x,y,w):
    p=ROOT/'验收'/name
    if p.exists():
        iw,ih=Image.open(p).size;c.drawImage(str(p),x,H-y-w*ih/iw,width=w,height=w*ih/iw,mask='auto')
def begin(tag,title,subtitle='',dark=False):
    global page_no,current
    page_no+=1;current=[]
    bg=INK if dark else '#FFFFFF';fg='#FFFFFF' if dark else INK
    rect(0,0,W,H,bg);text(48,27,'SNAPTILER / VISUAL IDENTITY',10,'#A4B5CD' if dark else MUTED)
    text(735,27,f'1.0  /  2026.09.20  /  {page_no:02d}',10,'#A4B5CD' if dark else MUTED)
    line(48,54,912,54,'#3A4962' if dark else '#DCE3EC')
    text(48,82,tag,11,BLUE if not dark else '#77B7FF');text(48,109,title,30,fg)
    if subtitle:para(48,156,subtitle,850,12,'#A4B5CD' if dark else MUTED,20)
    line(48,592,912,592,'#3A4962' if dark else '#DCE3EC')
    text(48,606,'窗多多 / SnapTiler  ·  A 宽厚方切  ·  透明底双窗口',10,'#A4B5CD' if dark else MUTED)
    pages.append({'title':title,'tag':tag,'subtitle':subtitle})
def end():c.showPage()

begin('BRAND GUIDELINES','VI 规范使用手册','以清晰的结构，保留一点亲和感。',True)
asset('lockup-bilingual-dark',170,252,w=620)
text(48,548,'选定方向：A · 宽厚方切',14,'#FFFFFF');text(614,549,'网站 / App 设置 / 品牌传播',13,'#A4B5CD');end()

begin('01 / BRAND FOUNDATION','一种识别，两个性格。','白蓝双窗口提供亲和感；宽厚、方切的专用字标提供稳定感和力量。')
asset('symbol-color',98,239,w=285)
text(476,224,'品牌名称',18);para(476,260,'中文：窗多多\n英文：SnapTiler（S、T 大写）\n用途：Mac 窗口整理工具的品牌识别。',385,15,INK,30)
text(476,382,'统一原则',18);para(476,418,'网站与 App 设置直接使用透明底 Logo。白蓝窗口的轮廓、表情与交叠关系固定；文字采用 A 版宽厚方切。紫色 App 图标底板不属于本手册中的界面签名。',385)
end()

begin('02 / LOGO LOCKUPS','三种标准组合。','优先使用完整组合文件，保持母版的图文比例、字距与对齐关系。')
text(48,249,'01  中英双语 / 品牌介绍',13);asset('lockup-bilingual-color',350,211,w=510)
line(48,404,912,404)
text(48,422,'02  中文 / 中文界面',13);asset('lockup-zh-color',48,459,w=350)
text(514,422,'03  英文 / 其他语言界面',13);asset('lockup-en-color',514,467,w=385)
end()

begin('03 / SIGNATURE LETTERING','宽厚方切，形状有据。','此处是专用品牌字标，不是完整、可安装的中英文字体。')
asset('wordmark-zh-ink',64,220,w=450);asset('wordmark-en-ink',64,425,w=460)
para(596,228,'中文：宽厚字面与平切收笔。\n“窗”保留直角围合框和两个方点。\n两个“多”共用同一份路径，禁止分别重画。',304,14,INK,27)
para(596,407,'英文：保留 S、T 大写，采用方形 i 字点和平切端头。必要的字母曲线保持平滑；不得用系统字体替代字标。',304,14,INK,27)
end()

begin('04 / COLOR','白蓝为主，墨蓝为字。','屏幕资产统一使用 sRGB。印刷请依据纸张、设备和 ICC 配置进行转换与打样。')
palette=[('窗口蓝','#0876FA','图形主色 / 鲜明识别'),('暖瓷白','#FFFDF7','窗口表面 / 保留暖调'),('墨蓝','#18213B','字标 / 主要文字'),('轮廓灰','#8796AE','浅色背景的细边线'),('雾灰白','#F6F8FB','中性页面 / 展示底色')]
for i,(name,hx,usage) in enumerate(palette):
    x=48+i*176;rect(x,230,160,155,hx,'#E4E9F0');text(x,405,name,16);text(x,437,hx,13,MUTED);para(x,471,usage,158,12)
end()

begin('05 / CLEAR SPACE','留白，也是标志的一部分。','以独立图形的可见高度 D 为基准。四周最小安全留白与图文间距均为 D / 4。')
bw,bh=asset('lockup-bilingual-color',211,268,w=530);pad=43
for a,b,d,e in [(211-pad,268-pad,211+bw+pad,268-pad),(211-pad,268+bh+pad,211+bw+pad,268+bh+pad),(211-pad,268-pad,211-pad,268+bh+pad),(211+bw+pad,268-pad,211+bw+pad,268+bh+pad)]:line(a,b,d,e,BLUE,[4,4])
text(169,201,'D / 4',12,BLUE);text(763,313,'D',15,BLUE)
para(48,502,'不要让正文、边框或其他图形侵入这一区域。组合内的中文、英文与图形由文件统一定位，放置时只等比缩放整个组合。',864,14)
end()

begin('06 / SIZE','尺寸越小，越要保留结构。','以下为屏幕使用建议；导航与 App 侧栏采用经实际界面检查的紧凑组合。')
for x,size in [(65,32),(151,48),(261,80)]:asset('symbol-color',x,267,h=size);text(x,369,f'{size} px',12,MUTED)
text(470,222,'展示型组合建议宽度',17)
for label,value,y in [('中文组合','180 px 起',272),('英文组合','240 px 起',320),('中英双语','240 px 起',368)]:text(470,y,label,14);text(725,y,value,14,BLUE)
para(48,452,'网站导航约 88-149 CSS px；App 设置侧栏 128 pt，「关于」176 pt。紧凑位置优先单语组合，检查字形开口与两枚方点是否可辨。16 px 浏览器图标仅用于识别，禁止加入字标。',864,14)
end()

begin('07 / BACKGROUNDS','在浅底清楚，在深底也清楚。','每种配色都来自同一套几何。选择正确文件，不给标志临时垫色块。')
for x,y,v,bg,label in [(48,219,'color','#F6F8FB','浅底 / color'),(496,219,'dark','#18213B','深底彩色 / dark'),(48,406,'black','#FFFFFF','单黑 / black'),(496,406,'white','#30343D','反白 / white')]:
    rect(x,y,416,158,bg,'#DCE3EC' if v!='dark' else None);asset('lockup-zh-'+v,x+47,y+18,w=322);text(x+16,y+133,label,10,'#FFFFFF' if v in ['white','dark'] else MUTED)
end()

begin('08 / MISUSE','保持形状，避免额外包装。','字标的力量来自自身结构；装饰、拉伸与替换都会破坏识别的一致性。')
rules=[('01','不要加紫色底板','网站与 App 设置使用真实透明背景。'),('02','不要单独拉宽或压扁','图形与文字作为整组等比缩放。'),('03','不要换成系统字体','始终使用已转轮廓的专用字标文件。'),('04','不要额外描边或发光','不增加阴影、渐变或立体效果。'),('05','不要改变图形关系','保持窗口的前后、倾角、眼睛与笑脸。'),('06','不要沿用旧版字形','A5 圆润版、B 窄长版均非当前母版。')]
for i,(num,title,body) in enumerate(rules):
    x=48+(i%2)*448;y=219+(i//2)*114;line(x,y,x+416,y);text(x,y+16,num,13,BLUE);text(x+43,y+14,title,17);para(x+43,y+46,body,365,12)
end()

begin('09 / DIGITAL APPLICATION','同一套母版，进入真实界面。','网站页头与页脚采用单语组合；App 设置侧栏与「关于」使用同源的透明 PNG。')
screenshot('website-zh.png',48,224,415);screenshot('app-settings-zh.png',496,224,415)
text(48,536,'本地官网 / 中文入口',13);text(496,536,'安装版 App / 设置侧栏',13)
end()

begin('10 / FILES & DELIVERY','拿对文件，就能用对。','完整资产保存在本手册所在目录；优先选用 SVG，需位图时使用透明 PNG。')
rows=[('SVG/','22 份矢量母版，可无损缩放与编辑'),('PNG/','22 份透明组合与字标，另附 4 个网站图标尺寸'),('源文件/','字形路径、参数、生成脚本与选定参考'),('VI规范使用手册.html','离线可打开的规范与素材索引'),('窗多多-SnapTiler-VI规范使用手册.pdf','本手册，用于传阅与打印')]
for i,(name,desc) in enumerate(rows):
    y=220+i*53;line(48,y,912,y);text(48,y+13,name,12);text(393,y+13,desc,12,MUTED)
para(48,510,'命名示例：lockup-zh-color.svg = 中文彩色组合；lockup-en-dark.png = 英文深底彩色组合。wordmark 为纯字标，symbol 为独立图形。当前版本 A-Cut 1.0，后续替换须统一更新母版、网站副本、App 资源与本手册。',864,12)
end();c.save()

sections=[]
for name,label in [('bilingual','中英双语'),('zh','中文组合'),('en','英文组合')]:
    sections.append(f'<article><h3>{label}</h3><img src="SVG/lockup-{name}-color.svg" alt="{label}"><p><a href="SVG/lockup-{name}-color.svg" download>下载 SVG</a> · <a href="PNG/lockup-{name}-color.png" download>下载 PNG</a></p></article>')
blocks=''.join(f'<div class="swatch"><span style="background:{hx}"></span><b>{name}</b><code>{hx}</code><p>{usage}</p></div>' for name,hx,usage in palette)
html_doc='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>窗多多 / SnapTiler · VI 规范使用手册</title><style>
*{box-sizing:border-box}body{margin:0;color:#18213b;background:#f6f8fb;font:16px/1.8 -apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif}main{max-width:1100px;margin:auto;padding:48px 28px}header{padding:60px 0}h1{font-size:42px;line-height:1.3}h2{font-size:26px;margin:0 0 24px}h3{font-size:17px}section{padding:38px 0;border-top:1px solid #dce3ec}a{color:#0876fa}img{max-width:100%;height:auto}header img{width:620px;margin:35px 0}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px}article{padding:28px;background:white}article img{height:130px;width:100%;object-fit:contain}.palette{display:grid;grid-template-columns:repeat(5,1fr);gap:14px}.swatch span{display:block;height:110px;border:1px solid #dce3ec}.swatch b,.swatch code{display:block;margin-top:12px}.swatch p{font-size:12px}.dark{background:#18213b;color:white}.rules{padding:30px;background:white}li{margin:10px 0}.sizes{display:flex;align-items:center;gap:35px;padding:28px 0}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:14px;border-bottom:1px solid #dce3ec}small{color:#69788e}@media(max-width:640px){.grid{grid-template-columns:1fr}.palette{grid-template-columns:repeat(2,1fr)}h1{font-size:32px}main{padding:25px 20px}td,th{font-size:13px;padding:10px 6px}}@media print{main{padding:0}article{break-inside:avoid}a{color:inherit}}
</style><main><header><small>SNAPTILER / VISUAL IDENTITY / 1.0</small><h1>VI 规范使用手册</h1><p>A · 宽厚方切字标，透明底白蓝双窗口。</p><img src="SVG/lockup-bilingual-color.svg" alt="窗多多 SnapTiler 品牌主组合"><p><a href="窗多多-SnapTiler-VI规范使用手册.pdf">查看完整 PDF 手册</a></p></header>
<section><h2>01 / 标准组合</h2><p>网站与 App 设置不使用紫色底板。优先使用完整组合文件，保持图文比例、字距与对齐。</p><div class="grid">'''+''.join(sections)+'''<article><h3>独立图形</h3><img src="SVG/symbol-color.svg" alt="独立白蓝双窗口"><p>作为图标使用，不额外加底板。</p></article></div></section>
<section><h2>02 / 专用字标</h2><div class="grid"><article><img src="SVG/wordmark-zh-ink.svg" alt="窗多多"><p>直角框、两个方点、平切笔画；两个“多”共用路径。</p></article><article><img src="SVG/wordmark-en-ink.svg" alt="SnapTiler"><p>S、T 大写，方形 i 字点；曲线仅用于必要的字母结构。</p></article></div><p>字标已转为轮廓，不是完整可安装字体；不要用正文排版字体替代。</p></section>
<section><h2>03 / 品牌配色</h2><div class="palette">'''+blocks+'''</div><p>屏幕使用 sRGB。印刷按纸张与输出设备转换，并先打样。</p></section>
<section><h2>04 / 留白与尺寸</h2><div class="rules"><p>以图形可见高度 D 为基准，图文间距与四周安全留白均为 D/4。</p><p>展示组合建议：中文 180 px 起，英文与双语 240 px 起。网站导航与 App 设置采用实际检查的紧凑单语组合。独立图形建议至少 32 px；16 px favicon 仅用于识别。</p><div class="sizes"><img src="SVG/symbol-color.svg" width="32" alt="32像素"><img src="SVG/symbol-color.svg" width="48" alt="48像素"><img src="SVG/symbol-color.svg" width="80" alt="80像素"></div></div></section>
<section><h2>05 / 深浅背景</h2><div class="grid"><article><h3>浅底 / color</h3><img src="SVG/lockup-zh-color.svg" alt="浅底组合"></article><article class="dark"><h3>深底 / dark</h3><img src="SVG/lockup-zh-dark.svg" alt="深底彩色组合"></article><article><h3>单黑 / black</h3><img src="SVG/lockup-zh-black.svg" alt="单黑组合"></article><article class="dark"><h3>反白 / white</h3><img src="SVG/lockup-zh-white.svg" alt="反白组合"></article></div></section>
<section><h2>06 / 使用禁则</h2><ul>'''+''.join(f'<li><b>{title}：</b>{body}</li>' for _,title,body in rules)+'''</ul></section><section><h2>07 / 真实应用</h2><div class="grid"><article><h3>本地官网</h3><img style="height:auto" src="验收/website-zh.png" alt="本地官网实际截图"></article><article><h3>安装版 App 设置</h3><img style="height:auto" src="验收/app-settings-zh.png" alt="安装版App设置实际截图"></article></div></section>
<section><h2>08 / 文件索引</h2><table><tr><th>目录 / 文件</th><th>用途</th></tr>'''+''.join(f'<tr><td>{html.escape(name)}</td><td>{html.escape(desc)}</td></tr>' for name,desc in rows)+'''</table><p>命名：lockup 为组合，wordmark 为纯字标，symbol 为独立图形；zh / en 为中文 / 英文；color / dark / black / white 为浅底彩色 / 深底彩色 / 单黑 / 反白。</p></section><footer><small>窗多多 / SnapTiler · A-Cut 1.0 · 2026-09-20 · ai798Lab</small></footer></main></html>'''
(ROOT/'VI规范使用手册.html').write_text(html_doc)
(ROOT/'源文件/manual-pages.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2))
print(f'Created {len(pages)} PDF pages and HTML manual: {out}')
