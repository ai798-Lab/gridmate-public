#!/usr/bin/env python3
"""Rebuild every SVG from the shared editable glyphs and logo geometry. No font dependency."""
from pathlib import Path
import json,html
ROOT=Path(__file__).resolve().parents[1]
INK='#18213B'
glyphs=json.loads((ROOT/'源文件/glyphs.json').read_text())['glyphs']
geometry=json.loads((ROOT/'源文件/logo-geometry.json').read_text())
runs=[[6,107],[120,199],[211,291],[306,389],[397,489],[499,522],[537,559],[573,655],[669,723]]
(ROOT/'SVG').mkdir(exist_ok=True)
def commands(v):return ' '.join(c[0]+' '.join(map(str,c[1:])) for c in v)
def symbol(variant='color'):
    blue,ivory,smile=(commands(geometry[k]) for k in ['blue','ivory','smile'])
    face='<rect x="226" y="418" width="47" height="109" rx="23.5"/><rect x="394" y="371" width="47" height="110" rx="23.5"/>'+f'<path d="{smile}" fill="none" stroke="currentColor" stroke-width="27" stroke-linecap="round"/>'
    if variant in ['color','dark']:
        border='#8796AE' if variant=='color' else '#FFFDF7'
        edge='M401 738 L193 792 C153 802 120 774 120 733 L120 330 C120 292 141 268 177 258 L468 181 C511 170 548 202 548 246 L548 361'
        body=f'<path d="{blue}" fill="#0876FA"/><path d="{ivory}" fill="#FFFDF7"/><path d="{edge}" fill="none" stroke="{border}" stroke-width="10" stroke-linejoin="round"/><g fill="{INK}" color="{INK}">{face}</g>'
    else:
        c='#111111' if variant=='black' else '#FFFFFF'
        body=f'<path d="{ivory}" fill="none" stroke="{c}" stroke-width="27" stroke-linejoin="round"/><path d="{blue}" fill="{c}"/><g fill="{c}" color="{c}">{face}</g>'
    return f'<g transform="translate(-100 -157)">{body}</g>',808,747

def word(lang):
    keys=['chuang','duo','duo'] if lang=='zh' else list('SnapTiler');x=0;out=[]
    # Preserve source A letterspacing; both 多 share one path definition.
    for i,k in enumerate(keys):
        if lang=='en':x=runs[i][0]-runs[0][0]
        out.append(f'<use href="#glyph-{k}" transform="translate({x:.3f} 0)"/>')
        if lang=='zh':x+=glyphs[k]['width']+(26 if i<2 else 0)
    return ''.join(out),x if lang=='zh' else runs[-1][1]-runs[0][0],200 if lang=='zh' else 130

def defs():return '<defs>'+''.join(f'<path id="glyph-{k}" d="{g["path"]}" fill-rule="evenodd"/>' for k,g in glyphs.items())+'</defs>'
def svg(body,w,h,title):return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w:.3f}" height="{h:.3f}" viewBox="0 0 {w:.3f} {h:.3f}" role="img" aria-label="{html.escape(title)}"><title>{html.escape(title)}</title>{defs() if "#glyph-" in body else ""}{body}</svg>'
def color(v):return '#FFFFFF' if v in ['white','dark'] else '#111111' if v=='black' else INK
def word_at(lang,x,y,s,v):
    b,w,h=word(lang);return f'<g fill="{color(v)}" transform="translate({x:.3f} {y:.3f}) scale({s:.6f})">{b}</g>'
def lockup(lang,v):
    b,iw,ih=symbol(v);s=160/ih;x=iw*s+40;body=f'<g transform="scale({s:.6f})">{b}</g>'
    if lang=='bilingual':
        zs=.40;es=.28;zh=80;eh=130*es;gap=14;y=(160-zh-eh-gap)/2
        body+=word_at('zh',x,y,zs,v)+word_at('en',x,y+zh+gap,es,v)
        w=x+max(word('zh')[1]*zs,word('en')[1]*es)
    else:
        scl=.45 if lang=='zh' else .62
        body+=word_at(lang,x,(160-word(lang)[2]*scl)/2,scl,v)
        w=x+word(lang)[1]*scl
    return body,w,160
assets={}
def save(name,body,w,h):
    (ROOT/'SVG'/f'{name}.svg').write_text(svg(body,w,h,'窗多多 / SnapTiler · A 宽厚方切 · '+name))
    assets[name]={'width':round(w,3),'height':round(h,3)}
for v in ['color','dark','black','white']:
    save('symbol-'+v,*symbol(v))
    for lang in ['zh','en','bilingual']:save(f'lockup-{lang}-{v}',*lockup(lang,v))
for lang in ['zh','en']:
    b,w,h=word(lang)
    for v in ['ink','black','white']:save(f'wordmark-{lang}-{v}',f'<g fill="{color(v)}">{b}</g>',w,h)
board='<rect width="1600" height="1000" fill="#fff"/>'
for lang,x,y,desired in [('bilingual',330,125,940),('zh',75,650,640),('en',890,650,640)]:
    b,w,h=lockup(lang,'color');board+=f'<g transform="translate({x} {y}) scale({desired/w})">{b}</g>'
(ROOT/'源文件/组合总览.svg').write_text(svg(board,1600,1000,'A 宽厚方切 · 无紫底组合'))
(ROOT/'源文件/glyphs.json').write_text(json.dumps({'version':'A-Cut 1.0','source':'user-selected A wide square-cut concept','glyphs':glyphs},ensure_ascii=False,indent=2))
(ROOT/'源文件/metrics.json').write_text(json.dumps({'assets':assets,'logo_height':160,'icon_text_gap':40,'safe_space':'D/4','selected':'A wide square cut'},ensure_ascii=False,indent=2))

print("Rebuilt 22 shared SVG masters.")
