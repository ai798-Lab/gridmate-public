const fs=require('fs');
const path=require('path');
const sharp=require(process.env.SHARP_MODULE || 'sharp');
const root=path.resolve(__dirname,'..');
(async()=>{
  for(const name of fs.readdirSync(path.join(root,'SVG')).filter(n=>n.endsWith('.svg'))){
    await sharp(path.join(root,'SVG',name),{density:216}).png().toFile(path.join(root,'PNG',name.replace('.svg','.png')));
  }
  await sharp(path.join(root,'源文件/组合总览.svg')).png().toFile(path.join(root,'组合总览.png'));
  const icon=path.join(root,'SVG/symbol-color.svg');
  for(const size of [32,180,192,512]){
    await sharp(icon,{density:144}).resize(size,size,{fit:'contain',background:'#00000000'}).png().toFile(path.join(root,'PNG',`icon-${size}.png`));
  }
  console.log('Rendered 22 transparent brand assets, 4 web icons and overview.');
})().catch(e=>{console.error(e);process.exit(1)});
