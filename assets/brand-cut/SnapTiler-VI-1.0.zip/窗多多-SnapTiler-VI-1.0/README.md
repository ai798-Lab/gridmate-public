# 窗多多 / SnapTiler · VI 规范与品牌资产 1.0

用户选定版本：**A · 宽厚方切**。中文品牌名为「窗多多」，英文为「SnapTiler」（S、T 大写）。网站和 App 设置使用透明底白蓝双窗口，不添加紫色底板。

## 从哪里开始

- **阅读完整规范**：[11 页 PDF 手册](窗多多-SnapTiler-VI规范使用手册.pdf)
- **浏览与直接取用**：[离线 HTML 手册](VI规范使用手册.html)
- **快速看组合**：[组合总览](组合总览.png)
- **编辑或开发使用**：优先从 `SVG/` 取文件；需要位图时从 `PNG/` 取透明 PNG。

手册涵盖品牌原则、三种标准组合、中英文字标、品牌配色、安全留白、最小尺寸、深浅背景适配、使用禁则、网站与 App 应用，以及文件命名。

## 选什么文件

| 场景 | 推荐文件 |
|---|---|
| 中文网页与 App 浅色界面 | `SVG/lockup-zh-color.svg` 或同名 PNG |
| 英文网页与 App 浅色界面 | `SVG/lockup-en-color.svg` 或同名 PNG |
| 品牌介绍、对外材料 | `SVG/lockup-bilingual-color.svg` |
| 深色界面，保留白蓝窗口 | `lockup-zh-dark` / `lockup-en-dark` / `lockup-bilingual-dark` |
| 单色印刷 | `black` 或 `white` 版本 |
| 独立图形 | `symbol-color` / `symbol-dark` / `symbol-black` / `symbol-white` |
| 仅用字标 | `wordmark-zh-*` / `wordmark-en-*` |
| 浏览器与网站图标 | `PNG/icon-32.png`、`icon-180.png`、`icon-192.png`、`icon-512.png` |

`color` 为浅底彩色，`dark` 为深底彩色（白色字标），`black` 为单黑，`white` 为反白。所有版本均为透明底。深色示例中的色块是展示背景，不属于 Logo 文件。

## 素材清单

- `SVG/`：22 份独立矢量资产；字标为路径，无需安装字体。
- `PNG/`：22 份对应透明 PNG，另附 4 份网站图标，共 26 份。
- `源文件/glyphs.json`：共享字形轮廓；两个「多」使用相同路径。
- `源文件/logo-geometry.json`：固定双窗口图形轮廓。
- `源文件/metrics.json`：尺寸与组合参数。
- `源文件/build_assets.py`：从共享轮廓重新生成全部 SVG，仅需 Python 3 标准库。
- `源文件/export_assets.cjs`：用 Node.js 和 sharp 将 SVG 导出为 PNG。
- `源文件/build_manual.py`：PDF 和 HTML 手册的可编辑生成源，需要 ReportLab、Pillow 及中文字体。
- `源文件/已选A字标参考.png`：选定方案参考；实际使用请取 SVG / PNG 母版。
- `验收/`：真实应用截图。完整项目目录另保留浏览器和 PDF 排版验收图。

## 使用要点

1. 优先使用完整组合，整组等比缩放，不单独改变图形与字标比例。
2. 图形可见高度为 D；四周至少保留 D/4 安全留白，组合图文间距固定为 D/4。
3. 不使用紫色底板，不给字标增加圆角、描边、阴影或发光。
4. 字标是专用品牌签名，不是一套完整可安装字体；正文继续使用界面字体。
5. 屏幕配色使用 sRGB；印刷应按实际纸张和输出设备转换并先打样。
6. A5 圆润版及 B 窄长版是历史提案，不作为当前母版。

## 重建

```sh
python3 源文件/build_assets.py
# 已有 sharp 依赖的 Node.js 环境中：
node 源文件/export_assets.cjs
# 已有 ReportLab、Pillow 和中文字体的环境中：
python3 源文件/build_manual.py
```

`build_manual.py` 当前使用 macOS 自带 Arial Unicode 中文字体路径；其他系统需替换为当地可用的中文 TTF。正式交付 PDF 已嵌入所用字体子集，阅读时不需额外安装。

更新顺序：修改共享轮廓 → 生成 SVG → 导出 PNG → 更新界面副本 → 重建手册 → 检查真实界面。不要只替换某一张展示图。

版本：A-Cut 1.0 · 2026-09-20。
