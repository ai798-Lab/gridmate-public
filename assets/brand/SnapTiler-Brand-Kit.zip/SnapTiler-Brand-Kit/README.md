# 窗多多 / SnapTiler 品牌资产 v1.0

日期：2026-09-20。已选方向：O4「柔光渐层」。

## 文件使用

- `svg/symbol-color.svg`：彩色主图标，透明四角，无外围留白。
- `svg/app-icon.svg`：macOS 专用画布，824/1024 安全区；不可拿普通满版图直接替代。
- `svg/menu-template.svg`：18 pt 菜单栏光学校正版，主标交叠轮廓与放大眼睛，交给系统着色。
- `svg/wordmark-zh-*.svg`、`wordmark-en-*.svg`：窗多多 / SnapTiler 独立字标，已转路径。
- `svg/lockup-zh-*`、`lockup-en-*`、`lockup-bilingual-*`、`lockup-stacked-*`：中文横版、英文横版、中英横版、中英竖版。
- 后缀 `ink` 为彩色图标与墨蓝字标；`black` 为单色黑；`white` 为透明底反白。
- `png/`：透明 PNG 与 16、32、48、64、128、256、512、1024 像素彩色图标。
- `AppIcon.iconset/`、`AppIcon.icns`：完整 macOS 多尺寸图标。
- `品牌规范.html`：离线品牌规范，可在浏览器打开并打印为 PDF。
- `source/`：矢量制作脚本、共用几何与字标尺寸，不是从概念图裁切的图片。
- `licenses/`：底稿字体的原始开源许可。

## 视觉规范

核心颜色：柔光紫 #ABA2FF，窗口蓝 #0876FA，暖瓷白 #FFFDF7，墨蓝 #18213B，雾灰白 #F8F8FC。
背景渐层：#B8B0FF → #ABA2FF → #968CFA，左上方漫射光。不额外添加颗粒、厚边、玻璃高光或外发光。

安全留白为图标边长 D 的 1/4。保持锁定的图文比例和对齐。彩色图标建议至少 32 px；16 px favicon 是极小识别用途。18 pt 菜单栏保留主标交叠轮廓与放大眼睛。中文横版最小建议宽度 160 px，英文横版 180 px，双语横版 220 px。小于这些尺寸，优先使用独立图标。

单色版通过轮廓/实心区分白蓝窗口，表情跟随同色；反白稿放在深色底。不要拉伸图形、改变前后窗口、对字标加阴影描边，或把概念图截图当作标志母版。

## 字标与来源

这套交付是品牌专用字标，不是完整可安装字体。文字均为矢量轮廓，无字体安装依赖。
中文字标以 Noto Sans CJK SC Black 为底稿，采用 89% 字面宽度、统一字距与切角；英文字标以 Manrope 800 为底稿，逐字调整间距，修改端点并重绘 i 的斜切字点。参考图只用于理解厚笔画、紧凑比例与几何收笔，不使用其图形标志。

- Noto Sans CJK 官方来源：https://github.com/notofonts/noto-cjk/tree/main/Sans/OTF/SimplifiedChinese
- Noto Sans CJK 许可：https://github.com/notofonts/noto-cjk/blob/main/Sans/LICENSE
- Manrope 官方分发：https://github.com/google/fonts/tree/main/ofl/manrope
- Manrope 许可：https://github.com/google/fonts/blob/main/ofl/manrope/OFL.txt

来源文件下载日期 2026-09-20。两份原始许可随包保存。公开品牌包不包含整套字体二进制；需要重建时按来源下载至 `source/fonts/`（NotoSansCJKsc-Black.otf、Manrope.ttf）。

## 可复现制作

1. 使用 Python 3 与 fontTools 运行 `source/build_brand.py`，生成 23 个 SVG 及同几何的原生图标绘制代码。
2. 使用 Node.js 与 sharp 运行 `source/export_assets.cjs`（可用 SHARP_MODULE 指定本机依赖路径）。
3. `iconutil -c icns AppIcon.iconset -o AppIcon.icns` 封装 macOS 图标。

设计选择记录在项目 `design/BRAND_DECISIONS.md`。官网新版仅本地预览；下载开放状态依然由真实发行验收决定。
