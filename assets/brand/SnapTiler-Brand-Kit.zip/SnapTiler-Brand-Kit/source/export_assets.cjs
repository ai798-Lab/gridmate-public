// SVG-to-PNG production export. Requires sharp (no raster concept is edited).
const fs = require('fs');
const path = require('path');
const sharp = require(process.env.SHARP_MODULE || 'sharp');
const root = path.resolve(__dirname, '..');
const project = path.resolve(root, '../../..');
async function main() {
  for (const file of fs.readdirSync(path.join(root, 'svg')).filter(f => f.endsWith('.svg'))) {
    const source = path.join(root, 'svg', file);
    await sharp(source, { density: 144 }).png().toFile(path.join(root, 'png', file.replace('.svg', '.png')));
  }
  const site = path.join(project, 'website/assets/brand');
  const native = path.join(project, 'GridMate/Packaging/Brand');
  fs.mkdirSync(site, { recursive: true }); fs.mkdirSync(native, { recursive: true });
  for (const file of fs.readdirSync(path.join(root, 'svg'))) fs.copyFileSync(path.join(root, 'svg', file), path.join(site, file));
  fs.copyFileSync(path.join(root, 'svg/symbol-color.svg'), path.join(project, 'website/favicon.svg'));
  for (const size of [16, 32, 48, 64, 128, 256, 512, 1024]) {
    await sharp(path.join(root, 'svg/symbol-color.svg')).resize(size, size).png().toFile(path.join(root, `png/icon-${size}.png`));
  }
  for (const size of [32, 180, 192, 512]) {
    await sharp(path.join(root, 'svg/symbol-color.svg')).resize(size, size).png().toFile(path.join(site, `icon-${size}.png`));
  }
  for (const lang of ['zh', 'en']) {
    await sharp(path.join(root, `svg/wordmark-${lang}-black.svg`), { density: 144 }).png().toFile(path.join(native, `wordmark-${lang}-black.png`));
  }
  // macOS safe zone: 824-point artwork centered in a 1024-point canvas.
  const iconset = path.join(root, 'AppIcon.iconset'); fs.mkdirSync(iconset, { recursive: true });
  for (const size of [16, 32, 128, 256, 512]) {
    for (const scale of [1, 2]) await sharp(path.join(root, 'svg/app-icon.svg'), { density: 144 }).resize(size*scale, size*scale).png().toFile(path.join(iconset, `icon_${size}x${size}${scale===2?'@2x':''}.png`));
  }
  console.log('Exported outlined logos, 8 icon sizes, website assets, native wordmarks and macOS iconset.');
}
main().catch(error => { console.error(error); process.exit(1); });
