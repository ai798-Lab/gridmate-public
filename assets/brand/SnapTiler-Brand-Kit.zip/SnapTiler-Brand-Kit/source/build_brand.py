#!/usr/bin/env python3
"""Rebuild outlined brand assets from shared geometry and OFL font sources.

This creates vector artwork; it does not edit the selected raster concept.
"""
from pathlib import Path
import json
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.transformPen import TransformPen

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parents[2]
OUT = ROOT / 'svg'
OUT.mkdir(exist_ok=True)

# Top-left coordinates, 1024 unit square. The interlock and rising edges match O4.
white = [('M',120,330),('C',120,292,141,268,177,258),('L',468,181),
 ('C',511,170,548,202,548,246),('L',548,508),('C',548,544,532,564,499,572),
 ('L',443,587),('C',415,594,401,614,401,645),('L',401,738),('L',193,792),
 ('C',153,802,120,774,120,733),('Z',)]
blue = [('M',548,361),('L',793,297),('C',848,282,892,317,892,369),
 ('L',892,722),('C',892,767,870,792,829,802),('L',492,888),
 ('C',442,901,401,867,401,818),('L',401,645),('C',401,614,415,594,443,587),
 ('L',499,572),('C',532,564,548,544,548,508),('Z',)]
smile = [('M',312,562),('C',333,574,359,563,374,541)]
geometry = {'ivory':white,'blue':blue,'smile':smile}
(ROOT/'source/geometry.json').write_text(json.dumps(geometry,indent=2)+'\n')
def d(commands): return ' '.join(c[0]+' '.join(str(v) for v in c[1:]) for c in commands)
defs = '''<defs>
 <linearGradient id="lavender" x1="0%" y1="0%" x2="100%" y2="100%"><stop stop-color="#B8B0FF"/><stop offset=".55" stop-color="#ABA2FF"/><stop offset="1" stop-color="#968CFA"/></linearGradient>
 <radialGradient id="light" cx="20%" cy="13%" r="94%"><stop stop-color="#FFFFFF" stop-opacity=".28"/><stop offset=".57" stop-color="#FFFFFF" stop-opacity=".03"/><stop offset="1" stop-color="#FFFFFF" stop-opacity="0"/></radialGradient>
 <linearGradient id="ivory" x1="0%" y1="0%" x2="80%" y2="100%"><stop stop-color="#FFFFFF"/><stop offset="1" stop-color="#FFFDF7"/></linearGradient>
 <linearGradient id="blue" x1="0%" y1="70%" x2="100%" y2="20%"><stop stop-color="#0876FA"/><stop offset="1" stop-color="#0588FF"/></linearGradient>
 <linearGradient id="edge" x1="0%" y1="0%" x2="100%" y2="0%"><stop stop-color="#80DDFF" stop-opacity="0"/><stop offset=".6" stop-color="#ACF7FF" stop-opacity=".9"/><stop offset="1" stop-color="#B3F8FF" stop-opacity="0"/></linearGradient>
 <filter color-interpolation-filters="sRGB" id="contact" x="-20%" y="-20%" width="150%" height="150%"><feDropShadow dx="0" dy="6" stdDeviation="7" flood-color="#554DC7" flood-opacity=".12"/></filter>
</defs>'''
face = '<rect x="226" y="418" width="47" height="109" rx="23.5"/><rect x="394" y="371" width="47" height="110" rx="23.5"/>' + f'<path d="{d(smile)}" fill="none" stroke="currentColor" stroke-width="27" stroke-linecap="round"/>'
def icon(variant='color',inset=False):
    if variant=='color':
        body=f'''<rect width="1024" height="1024" rx="246" fill="url(#lavender)"/>
<rect width="1024" height="1024" rx="246" fill="url(#light)"/>
<g><path d="{d(blue)}" fill="url(#blue)"/><path d="{d(white)}" fill="url(#ivory)"/></g>
<path d="M550 361 L793 297 C820 290 843 294 862 307" fill="none" stroke="url(#edge)" stroke-width="3.5" stroke-linecap="round"/>
<g fill="#121C35" color="#121C35">{face}</g>'''
    else:
        color='#111111' if variant=='black' else '#FFFFFF'
        # A transparent white window, solid interlocking blue window and readable expression.
        body=f'<g fill="none" stroke="{color}" stroke-width="27" stroke-linejoin="round"><path d="{d(white)}"/></g><path d="{d(blue)}" fill="{color}"/><g fill="{color}" color="{color}">{face}</g>'
    return defs+ (f'<g transform="translate(100 100) scale(.8046875)">{body}</g>' if inset else body)
def svg(body,w,h,title): return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" role="img"><title>{title}</title>{body}</svg>\n'
def write(name,body,w,h,title): (OUT/(name+'.svg')).write_text(svg(body,w,h,title))
for variant in ['color','black','white']:
    write('symbol-'+variant,icon(variant),1024,1024,'窗多多 / SnapTiler')
write('app-icon',icon(inset=True),1024,1024,'窗多多 / SnapTiler — macOS')

zh=TTFont(ROOT/'source/fonts/NotoSansCJKsc-Black.otf')
en=instantiateVariableFont(TTFont(ROOT/'source/fonts/Manrope.ttf'),{'wght':800},inplace=False)
def outlined(font,text,height,width_scale,tracking,lang):
    glyphs=font.getGlyphSet(); cmap=font.getBestCmap()
    bounds=[]
    for c in text:
        p=BoundsPen(glyphs); glyphs[cmap[ord(c)]].draw(p);bounds.append(p.bounds)
    y0=min(b[1] for b in bounds);y1=max(b[3] for b in bounds)
    s=height/(y1-y0);x=0;elements=[];clips=[]
    for i,(c,b) in enumerate(zip(text,bounds)):
        glyph=glyphs[cmap[ord(c)]];pen=SVGPathPen(glyphs)
        # Compact Chinese body; Latin optically spaced individually.
        glyph.draw(TransformPen(pen,(s*width_scale,0,0,-s,x-b[0]*s*width_scale,y1*s)))
        width=(b[2]-b[0])*s*width_scale
        cid=f'{lang}-cut-{i}'
        # A small diagonal terminal at upper right, echoing the ascending window edges.
        cut=height*(.062 if lang=='zh' else .052)
        top=(y1-b[3])*s
        clips.append(f'<clipPath id="{cid}"><path d="M{x-2} -2 H{x+width-cut} L{x+width+2} {top+cut} V{height+2} H{x-2}Z"/></clipPath>')
        # The i is deliberately redrawn with an angled square dot and shared stem weight.
        if lang=='en' and c=='i':
            dot=width; gap=height*.075
            path=f'M{x} {top+dot*.22} L{x+dot} {top} V{top+dot*.85} L{x} {top+dot*1.07}Z M{x} {top+dot+gap}H{x+width}V{y1*s}H{x}Z'
        else: path=pen.getCommands()
        elements.append(f'<path d="{path}" clip-path="url(#{cid})"/>')
        x+=width+tracking+({'a':-1.6,'p':-.5,'T':-2.4,'i':.9,'l':.6}.get(c,0) if lang=='en' else 0)
    return '<defs>'+''.join(clips)+'</defs><g>'+''.join(elements)+'</g>',x-tracking,height
zbody,zw,zhh=outlined(zh,'窗多多',160,.89,11,'zh')
ebody,ew,eh=outlined(en,'SnapTiler',136,1,4.7,'en')
metrics={'zh':{'width':zw,'height':zhh},'en':{'width':ew,'height':eh}}
(ROOT/'source/wordmark-metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
for v,c in [('ink','#18213B'),('black','#111111'),('white','#FFFFFF')]:
    for lang,body,w,h in [('zh',zbody,zw,zhh),('en',ebody,ew,eh)]:
        write(f'wordmark-{lang}-{v}',f'<g fill="{c}">{body}</g>',round(w,3),h,'窗多多' if lang=='zh' else 'SnapTiler')
    variant='color' if v=='ink' else v
    mark=f'<g transform="translate(0 0) scale(.1875)">{icon(variant)}</g>'
    for lang,body,w,h in [('zh',zbody,zw,zhh),('en',ebody,ew,eh)]:
        scale=.66 if lang=='zh' else .7
        write(f'lockup-{lang}-{v}',mark+f'<g transform="translate(229 {(192-h*scale)/2}) scale({scale})" fill="{c}">{body}</g>',round(229+w*scale,3),192,f'窗多多 / SnapTiler {lang}')
    bilingual=mark+f'<g transform="translate(229 29) scale(.55)" fill="{c}">{zbody}</g><g transform="translate(232 139) scale(.255)" fill="{c}">{ebody}</g>'
    write(f'lockup-bilingual-{v}',bilingual,round(229+max(zw*.55,ew*.255),3),192,'窗多多 / SnapTiler')
    width=480; iscale=.234375
    stacked=f'<g transform="translate(120 0) scale({iscale})">{icon(variant)}</g><g transform="translate({(width-zw*.75)/2} 282) scale(.75)" fill="{c}">{zbody}</g><g transform="translate({(width-ew*.4)/2} 431) scale(.4)" fill="{c}">{ebody}</g>'
    write(f'lockup-stacked-{v}',stacked,width,500,'窗多多 / SnapTiler')

# Optical menu master: retain the interlock, enlarge eyes, omit subpixel smile.
menu=f'<g transform="translate(-1.12 -1.58) scale(.02)" fill="#000"><path d="{d(white)}" fill="none" stroke="#000" stroke-width="64" stroke-linejoin="round"/><path d="{d(blue)}"/><rect x="224" y="411" width="67" height="125" rx="33.5"/><rect x="392" y="365" width="67" height="125" rx="33.5"/></g>'
write('menu-template',menu,18,18,'SnapTiler')

# Native renderer shares the same path points as the SVG master above.
def swiftpath(cmds):
    lines=['let p = NSBezierPath()']
    for c in cmds:
        if c[0]=='M':lines.append(f'p.move(to: NSPoint(x: {c[1]}, y: {c[2]}))')
        if c[0]=='L':lines.append(f'p.line(to: NSPoint(x: {c[1]}, y: {c[2]}))')
        if c[0]=='C':lines.append(f'p.curve(to: NSPoint(x: {c[5]}, y: {c[6]}), controlPoint1: NSPoint(x: {c[1]}, y: {c[2]}), controlPoint2: NSPoint(x: {c[3]}, y: {c[4]}))')
        if c[0]=='Z':lines.append('p.close()')
    return '\n        '.join(lines)+'\n        return p'
native='''import AppKit

/// O4 柔光渐层。Generated from design/brand/2026-09-20/source/build_brand.py.
/// SVG and native icons share the same 1024-unit paths; no bitmap concept-sheet crops.
enum BrandIcon {
    private static func color(_ value: UInt32) -> NSColor {
        NSColor(srgbRed: CGFloat((value >> 16) & 255) / 255,
                green: CGFloat((value >> 8) & 255) / 255, blue: CGFloat(value & 255) / 255, alpha: 1)
    }
    static func appIcon(size: CGFloat, inset: Bool = false) -> NSImage {
        NSImage(size: NSSize(width: size, height: size), flipped: true) { rect in
            NSGraphicsContext.saveGraphicsState()
            defer { NSGraphicsContext.restoreGraphicsState() }
            let t = AffineTransform(scale: rect.width / 1024)
            (t as NSAffineTransform).concat()
            if inset { let t = NSAffineTransform(); t.translateX(by: 100, yBy: 100); t.scale(by: 0.8046875); t.concat() }
            let tile = NSBezierPath(roundedRect: NSRect(x: 0, y: 0, width: 1024, height: 1024), xRadius: 246, yRadius: 246)
            NSGradient(colors: [color(0xB8B0FF), color(0xABA2FF), color(0x968CFA)])!.draw(in: tile, angle: 45)
            NSGraphicsContext.saveGraphicsState()
            tile.addClip()
            NSGradient(starting: NSColor.white.withAlphaComponent(0.28), ending: NSColor.white.withAlphaComponent(0))!.draw(fromCenter: NSPoint(x: 205, y: 133), radius: 0, toCenter: NSPoint(x: 205, y: 133), radius: 963, options: .drawsAfterEndingLocation)
            NSGraphicsContext.restoreGraphicsState()
            NSGradient(starting: color(0x0876FA), ending: color(0x0588FF))!.draw(in: bluePath(), angle: -20)
            NSGradient(starting: .white, ending: color(0xFFFDF7))!.draw(in: ivoryPath(), angle: 65)
            let edge = NSBezierPath(); edge.move(to: NSPoint(x: 552, y: 360)); edge.line(to: NSPoint(x: 793, y: 297));
            color(0xACF7FF).withAlphaComponent(0.6).setStroke(); edge.lineWidth = 2.6; edge.stroke()
            color(0x121C35).setFill(); color(0x121C35).setStroke()
            for r in [NSRect(x: 226, y: 418, width: 47, height: 109), NSRect(x: 394, y: 371, width: 47, height: 110)] { NSBezierPath(roundedRect: r, xRadius: 23.5, yRadius: 23.5).fill() }
            let smile = smilePath(); smile.lineWidth = 27; smile.lineCapStyle = .round; smile.stroke()
            return true
        }
    }
    static func menuBarImage() -> NSImage {
        let image = NSImage(size: NSSize(width: 18, height: 18), flipped: true) { _ in
            NSGraphicsContext.saveGraphicsState()
            defer { NSGraphicsContext.restoreGraphicsState() }
            let transform = NSAffineTransform()
            transform.translateX(by: -1.12, yBy: -1.58)
            transform.scale(by: 0.02)
            transform.concat()
            NSColor.black.setFill()
            NSColor.black.setStroke()
            let outline = ivoryPath()
            outline.lineWidth = 64
            outline.lineJoinStyle = .round
            outline.stroke()
            bluePath().fill()
            // Optically enlarged eyes carry the character at menu-bar size.
            for rect in [NSRect(x: 224, y: 411, width: 67, height: 125),
                         NSRect(x: 392, y: 365, width: 67, height: 125)] {
                NSBezierPath(roundedRect: rect, xRadius: 33.5, yRadius: 33.5).fill()
            }
            return true
        }
        image.isTemplate = true
        return image
    }
    static func wordmark(chinese: Bool) -> NSImage? {
        guard let url = Bundle.main.url(forResource: chinese ? "wordmark-zh-black" : "wordmark-en-black", withExtension: "png", subdirectory: "Brand"), let image = NSImage(contentsOf: url) else { return nil }
        image.isTemplate = true
        return image
    }
'''
for key,name in [('ivory','ivoryPath'),('blue','bluePath'),('smile','smilePath')]:
    native+=f'    private static func {name}() -> NSBezierPath {{\n        {swiftpath(geometry[key])}\n    }}\n'
native+='}\n'
(PROJECT/'GridMate/Sources/GridMateApp/MenuBar/BrandIcon.swift').write_text(native)
print(f'Built {len(list(OUT.glob("*.svg")))} SVG masters and native renderer.')
